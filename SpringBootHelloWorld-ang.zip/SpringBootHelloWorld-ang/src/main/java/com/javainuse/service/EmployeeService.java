package com.javainuse.service;

import com.javainuse.model.Employee;

public interface EmployeeService {
	Employee saveEmployee(Employee emp);
}
