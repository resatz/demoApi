package com.javainuse.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.javainuse.model.Employee;


@RestController
public class EmployeeRestCtrl {

	
	@RequestMapping(value = "/getemployees",method = RequestMethod.GET)
	public List<Employee> firstPage() {
		List<Employee> emp=null;
		return emp;
	}
	

	@RequestMapping(value = "/deleteemployee",method = RequestMethod.DELETE)
	public Employee delete(@PathVariable("id") int id) {
		Employee deletedEmp = null;

		
		return deletedEmp;
	}

	@RequestMapping(value = "/addemployee",method = RequestMethod.POST)
	public Employee create(@RequestBody Employee user) {		
		System.out.println("");
		return user;
	}
	
	@RequestMapping(value = "/editemployee",method = RequestMethod.PUT)
	public Employee update(@RequestBody Employee user) {
	
		return user;
	}
	

}