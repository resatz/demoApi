package com.example.demoApi.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoApi.model.User;
import com.example.demoApi.repo.UserRepo;

@Service
public class UserService {

	@Autowired
	public UserRepo userRepo;
	
	public User saveUser(User user) {
		return this.userRepo.save(user);
	}
}
