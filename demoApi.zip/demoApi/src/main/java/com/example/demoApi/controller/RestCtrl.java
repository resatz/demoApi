package com.example.demoApi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoApi.model.User;
import com.example.demoApi.services.UserService;

@RestController
public class RestCtrl {

	@Autowired
	public UserService userService;

	@RequestMapping(value = "/registration",method = RequestMethod.POST)
	public User registration(@RequestBody User user) {
		return this.userService.saveUser(user);
	}
}
